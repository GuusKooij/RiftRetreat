"""
DataManager: Fetches, stores, and incrementally updates all player data.

Handles: matches, mastery, challenges, ranked stats, profile.
All data persisted as JSON in the data/ folder for offline use.
"""

import csv
import json
import os
import time
from datetime import datetime
from typing import Optional, Callable

from config import DATA_DIR, SEASON_START_TIMESTAMP
from src.api.riot_api import RiotAPI
from src.api.data_dragon import DataDragon


class DataManager:
    def __init__(self, game_name: str, tag_line: str, region: str = 'EUW', api_key: str = None):
        self.game_name = game_name
        self.tag_line = tag_line
        self.region = region
        self.api = RiotAPI(api_key=api_key, region=region) if api_key else RiotAPI(region=region)
        self.dd = DataDragon()
        self.puuid: Optional[str] = None

        # Data containers
        self.profile: dict = {}
        self.matches: list[dict] = []
        self.mastery: list[dict] = []
        self.challenges: dict = {}
        self.challenges_config: list[dict] = []
        self.ranked_stats: list[dict] = []
        self.climb_history: list[dict] = []
        self.past_seasons: list[dict] = []

        os.makedirs(DATA_DIR, exist_ok=True)

    def _path(self, filename: str) -> str:
        return os.path.join(DATA_DIR, filename)

    def _save_json(self, filename: str, data):
        with open(self._path(filename), 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

    def _load_json(self, filename: str, default=None):
        path = self._path(filename)
        if os.path.exists(path):
            with open(path, 'r', encoding='utf-8') as f:
                return json.load(f)
        return default

    # --- Load from disk ---

    def clear_all(self):
        """Clear all in-memory data (for account switching)."""
        self.profile = {}
        self.matches = []
        self.mastery = []
        self.challenges = {}
        self.challenges_config = []
        self.ranked_stats = []
        self.climb_history = []
        self.past_seasons = []
        self.puuid = None

    def load_all(self) -> bool:
        """Load all saved data from disk. Returns True if profile exists."""
        self.profile = self._load_json('profile.json', {})
        self.matches = self._load_json('matches.json', [])
        self.mastery = self._load_json('mastery.json', [])
        self.challenges = self._load_json('challenges.json', {})
        self.challenges_config = self._load_json('challenges_config.json', [])
        self.ranked_stats = self._load_json('ranked_stats.json', [])
        self.climb_history = self._load_json('climb_history.json', [])
        self.past_seasons = self._load_json('past_seasons.json', [])
        self.puuid = self.profile.get('puuid')
        return bool(self.puuid)

    # --- Fetch from API ---

    def fetch_profile(self) -> bool:
        """Fetch account info and PUUID."""
        account = self.api.get_account_by_riot_id(self.game_name, self.tag_line)
        if not account:
            return False

        self.puuid = account['puuid']
        summoner = self.api.get_summoner_by_puuid(self.puuid)

        self.profile = {
            'puuid': self.puuid,
            'game_name': account.get('gameName', self.game_name),
            'tag_line': account.get('tagLine', self.tag_line),
            'summoner_level': summoner.get('summonerLevel', 0) if summoner else 0,
            'profile_icon_id': summoner.get('profileIconId', 0) if summoner else 0,
            'region': self.region,
            'last_updated': datetime.now().isoformat(),
        }
        self._save_json('profile.json', self.profile)
        return True

    def fetch_ranked_stats(self) -> list[dict]:
        """Fetch current ranked stats and append to climb history."""
        if not self.puuid:
            return []

        entries = self.api.get_league_entries_by_puuid(self.puuid)
        if entries is None:
            return self.ranked_stats

        self.ranked_stats = entries
        self._save_json('ranked_stats.json', self.ranked_stats)

        # Append to climb history
        for entry in entries:
            snapshot = {
                'timestamp': datetime.now().isoformat(),
                'queue_type': entry.get('queueType', ''),
                'tier': entry.get('tier', ''),
                'rank': entry.get('rank', ''),
                'lp': entry.get('leaguePoints', 0),
                'wins': entry.get('wins', 0),
                'losses': entry.get('losses', 0),
            }
            self.climb_history.append(snapshot)

        self._save_json('climb_history.json', self.climb_history)
        return self.ranked_stats

    def fetch_mastery(self) -> list[dict]:
        """Fetch all champion mastery data."""
        if not self.puuid:
            return []

        data = self.api.get_champion_mastery(self.puuid)
        if data is None:
            return self.mastery

        self.mastery = data
        self._save_json('mastery.json', self.mastery)
        return self.mastery

    def fetch_challenges(self) -> dict:
        """Fetch player challenge progress."""
        if not self.puuid:
            return {}

        data = self.api.get_challenges_by_puuid(self.puuid)
        if data is None:
            return self.challenges

        self.challenges = data
        self._save_json('challenges.json', self.challenges)
        return self.challenges

    def fetch_challenges_config(self) -> list[dict]:
        """Fetch all challenge definitions (names, descriptions, thresholds)."""
        data = self.api.get_challenges_config()
        if data is None:
            return self.challenges_config

        self.challenges_config = data
        self._save_json('challenges_config.json', self.challenges_config)
        return self.challenges_config

    def fetch_matches(self, progress_callback: Optional[Callable] = None) -> list[dict]:
        """Fetch ranked matches incrementally (only new ones since last fetch).

        Args:
            progress_callback: Optional callable(current, total, message) for progress updates
        """
        if not self.puuid:
            return []

        # Determine start time: use last match timestamp or season start
        existing_ids = {m['match_id'] for m in self.matches}
        if self.matches:
            last_match_time = max(m['game_start'] for m in self.matches)
            last_timestamp = int(datetime.fromisoformat(last_match_time).timestamp())
        else:
            last_timestamp = SEASON_START_TIMESTAMP

        # Fetch match IDs for both queues
        if progress_callback:
            progress_callback(0, 0, "Fetching Solo/Duo match IDs...")

        solo_ids = self.api.get_all_match_ids(
            self.puuid, queue=420, start_time=last_timestamp
        )

        if progress_callback:
            progress_callback(0, 0, "Fetching Flex match IDs...")

        flex_ids = self.api.get_all_match_ids(
            self.puuid, queue=440, start_time=last_timestamp
        )

        # Filter out already-fetched matches
        new_ids = [mid for mid in (solo_ids + flex_ids) if mid not in existing_ids]

        if not new_ids:
            if progress_callback:
                progress_callback(0, 0, "No new matches found.")
            return self.matches

        total = len(new_ids)
        errors = 0
        start_time = time.time()

        for i, match_id in enumerate(new_ids, 1):
            if progress_callback:
                elapsed = time.time() - start_time
                rate = i / max(elapsed, 1)
                eta = int((total - i) / max(rate, 0.01))
                progress_callback(i, total, f"Fetching {match_id} (ETA: {eta}s)")

            match_data = self.api.get_match(match_id)
            if match_data is None:
                errors += 1
                continue

            stats = self._extract_player_stats(match_data)
            if stats is None:
                errors += 1
                continue

            self.matches.append(stats)

        # Sort by game start and save
        self.matches.sort(key=lambda m: m['game_start'])
        self._save_json('matches.json', self.matches)

        if progress_callback:
            progress_callback(total, total, f"Done! {total - errors} new matches fetched.")

        return self.matches

    def _extract_player_stats(self, match_data: dict) -> Optional[dict]:
        """Extract the player's stats from a full match data object."""
        info = match_data.get('info', {})
        participants = info.get('participants', [])

        player = None
        for p in participants:
            if p.get('puuid') == self.puuid:
                player = p
                break

        if player is None:
            return None

        game_duration_sec = info.get('gameDuration', 0)
        game_duration_min = game_duration_sec / 60

        # Calculate team kills for kill participation
        team_id = player.get('teamId')
        team_kills = sum(
            p.get('kills', 0) for p in participants if p.get('teamId') == team_id
        )

        kills = player.get('kills', 0)
        deaths = player.get('deaths', 0)
        assists = player.get('assists', 0)
        cs = player.get('totalMinionsKilled', 0) + player.get('neutralMinionsKilled', 0)

        kp = round((kills + assists) / max(team_kills, 1) * 100, 1)
        champion_id = player.get('championId')

        return {
            'match_id': match_data['metadata']['matchId'],
            'game_start': datetime.fromtimestamp(info['gameStartTimestamp'] / 1000).isoformat(),
            'game_duration_min': round(game_duration_min, 1),
            'queue_id': info.get('queueId'),
            'game_version': info.get('gameVersion', ''),

            'champion': player.get('championName'),
            'champion_id': champion_id,
            'champion_name': self.dd.get_champion_name(champion_id),
            'role': player.get('teamPosition') or player.get('individualPosition', ''),
            'win': player.get('win', False),

            'kills': kills,
            'deaths': deaths,
            'assists': assists,
            'kill_participation': kp,

            'total_damage_dealt': player.get('totalDamageDealtToChampions', 0),
            'physical_damage': player.get('physicalDamageDealtToChampions', 0),
            'magic_damage': player.get('magicDamageDealtToChampions', 0),
            'damage_taken': player.get('totalDamageTaken', 0),

            'cs': cs,
            'cs_per_min': round(cs / max(game_duration_min, 1), 1),
            'gold_earned': player.get('goldEarned', 0),

            'vision_score': player.get('visionScore', 0),
            'wards_placed': player.get('wardsPlaced', 0),
            'wards_killed': player.get('wardsKilled', 0),
            'control_wards': player.get('detectorWardsPlaced', 0),

            'turret_kills': player.get('turretKills', 0),
            'inhibitor_kills': player.get('inhibitorKills', 0),
            'dragon_kills': player.get('dragonKills', 0),
            'baron_kills': player.get('baronKills', 0),

            'double_kills': player.get('doubleKills', 0),
            'triple_kills': player.get('tripleKills', 0),
            'quadra_kills': player.get('quadraKills', 0),
            'penta_kills': player.get('pentaKills', 0),
            'first_blood': player.get('firstBloodKill', False),

            'items': [player.get(f'item{i}', 0) for i in range(7)],
            'summoner1': player.get('summoner1Id', 0),
            'summoner2': player.get('summoner2Id', 0),
            'team_id': team_id,

            # Teammate and opponent data for matchup/duo analysis
            'teammates': [
                {
                    'puuid': p.get('puuid', ''),
                    'summoner_name': p.get('riotIdGameName', '') or p.get('summonerName', ''),
                    'tag_line': p.get('riotIdTagline', ''),
                    'champion': p.get('championName', ''),
                    'champion_id': p.get('championId', 0),
                    'role': p.get('teamPosition', ''),
                }
                for p in participants
                if p.get('teamId') == team_id and p.get('puuid') != self.puuid
            ],
            'opponents': [
                {
                    'champion': p.get('championName', ''),
                    'champion_id': p.get('championId', 0),
                    'role': p.get('teamPosition', ''),
                }
                for p in participants
                if p.get('teamId') != team_id
            ],

            # Game-level data for comeback/throw analysis
            'game_end_gold_diff': self._calc_gold_diff(participants, team_id),
        }

    @staticmethod
    def _calc_gold_diff(participants, team_id):
        """Calculate gold difference at end of game (positive = team ahead)."""
        team_gold = sum(p.get('goldEarned', 0) for p in participants if p.get('teamId') == team_id)
        enemy_gold = sum(p.get('goldEarned', 0) for p in participants if p.get('teamId') != team_id)
        return team_gold - enemy_gold

    def migrate_matches(self, progress_callback: Optional[Callable] = None):
        """Re-fetch matches missing new fields (teammates, opponents, gold_diff)."""
        to_migrate = [m for m in self.matches if 'game_end_gold_diff' not in m]
        if not to_migrate:
            return

        total = len(to_migrate)
        errors = 0
        start_time = time.time()

        # Build index for fast lookup
        match_index = {m['match_id']: i for i, m in enumerate(self.matches)}

        for i, m in enumerate(to_migrate, 1):
            if progress_callback:
                elapsed = time.time() - start_time
                rate = i / max(elapsed, 1)
                eta = int((total - i) / max(rate, 0.01))
                progress_callback(i, total, f"Migrating {m['match_id']} ({i}/{total}, ETA: {eta}s)")

            match_data = self.api.get_match(m['match_id'])
            if match_data is None:
                errors += 1
                continue

            new_stats = self._extract_player_stats(match_data)
            if new_stats is None:
                errors += 1
                continue

            idx = match_index[m['match_id']]
            self.matches[idx] = new_stats

        self.matches.sort(key=lambda m: m['game_start'])
        self._save_json('matches.json', self.matches)

        if progress_callback:
            progress_callback(total, total, f"Migration done! {total - errors} matches updated.")

    # --- Convenience ---

    def fetch_all(self, progress_callback: Optional[Callable] = None) -> bool:
        """Fetch everything: profile, ranked, mastery, challenges, matches.

        Args:
            progress_callback: Optional callable(current, total, message)

        Returns:
            True if successful
        """
        if progress_callback:
            progress_callback(0, 0, "Looking up account...")

        if not self.fetch_profile():
            return False

        if progress_callback:
            progress_callback(0, 0, "Fetching ranked stats...")
        self.fetch_ranked_stats()

        if progress_callback:
            progress_callback(0, 0, "Fetching champion mastery...")
        self.fetch_mastery()

        if progress_callback:
            progress_callback(0, 0, "Fetching challenges...")
        self.fetch_challenges()

        if progress_callback:
            progress_callback(0, 0, "Fetching challenge definitions...")
        self.fetch_challenges_config()

        if progress_callback:
            progress_callback(0, 0, "Fetching matches...")
        self.fetch_matches(progress_callback=progress_callback)

        # Migrate old matches missing new fields
        if any('game_end_gold_diff' not in m for m in self.matches):
            if progress_callback:
                progress_callback(0, 0, "Migrating old matches with new fields...")
            self.migrate_matches(progress_callback=progress_callback)

        return True

    def get_solo_matches(self) -> list[dict]:
        return [m for m in self.matches if m['queue_id'] == 420]

    def get_flex_matches(self) -> list[dict]:
        return [m for m in self.matches if m['queue_id'] == 440]

    def get_ranked_entry(self, queue: str = 'RANKED_SOLO_5x5') -> Optional[dict]:
        for entry in self.ranked_stats:
            if entry.get('queueType') == queue:
                return entry
        return None

    def export_matches_csv(self, filepath: str = None) -> str:
        """Export match history to CSV file. Returns the filepath."""
        if filepath is None:
            filepath = self._path('matches_export.csv')

        columns = [
            'match_id', 'game_start', 'game_duration_min', 'queue_id',
            'champion', 'role', 'win',
            'kills', 'deaths', 'assists', 'kill_participation',
            'total_damage_dealt', 'cs', 'cs_per_min', 'gold_earned',
            'vision_score', 'wards_placed', 'wards_killed', 'control_wards',
            'turret_kills', 'dragon_kills', 'baron_kills',
            'double_kills', 'triple_kills', 'quadra_kills', 'penta_kills',
            'first_blood',
        ]

        with open(filepath, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=columns, extrasaction='ignore')
            writer.writeheader()
            for m in sorted(self.matches, key=lambda x: x['game_start'], reverse=True):
                writer.writerow(m)

        return filepath
